import pandas as pd
import numpy as np
import math
#part 2a
import matplotlib.pyplot as plt

df = pd.read_csv('landslide_data_miss.csv')#reaing data file


df = df.dropna(subset=['stationid'])


thr = len(df.columns) / 3


df = df.dropna(thresh=thr)


df.reset_index(drop=True, inplace=True)
print(df)


#part 2b



df = pd.read_csv('landslide_data_miss.csv')

# Function to perform linear interpolation for a single column
def linear_interpolation(column):
    interpolated_column = column.copy()
    for i in range(len(column)):
        if pd.isna(interpolated_column[i]):
            j = i - 1
            while pd.isna(interpolated_column[j]):
                j -= 1
            k = i + 1
            while pd.isna(interpolated_column[k]):
                k += 1
            
            if j >= 0 and k < len(column):
                x1, y1 = j, interpolated_column[j]
                x2, y2 = k, interpolated_column[k]
                x = i
                interpolated_value =  ((int(x) - int(x1)) / (int(x2) - int(x1)) )
                interpolated_column[i] = interpolated_value
    return interpolated_column

# Iterate through columns and apply linear interpolation to each column with missing values
for column in df.columns:
    if df[column].isna().any():
        df[column] = linear_interpolation(df[column])


req_df = df.copy()
# Save the DataFrame to a new CSV file if needed
df.to_csv('interpolated_dataset.csv', index=False)
print(df)

temperature1 = df['temperature'].tolist()
humidity1 = df['humidity'].tolist()
pressure1 = df['pressure'].tolist()
rain1 = df['rain'].tolist()
lightavg1 = df['lightavg'].tolist()
lightmax1 = df['lightmax'].tolist()
moisture1 = df['moisture'].tolist()
n=len(temperature1)
def mean(m):
    k=0
    for i in m:
        k=k+i
    me=round(k/n,2)
    return (me)

temean=mean(temperature1)
humean=mean(humidity1)
prmean=mean(pressure1)
ramean=mean(rain1)
lamean=mean(lightavg1)
lmmean=mean(lightmax1)
momean=mean(moisture1)



def median(me):
    me.sort()
    # finding the median
    n = len(me)
    if n % 2 == 0:
        median = round((me[n//2 - 1] + me[n//2]) / 2,2)
    else:
        median = round(me[n//2],2)
     # Print the median of the list
    print(median)

median(temperature1)
median(humidity1)
median(pressure1)
median(rain1)
median(lightavg1)
median(lightmax1)
median(moisture1)


def std_devi(dev,l):
    deviations = [(x - l) ** 2 for x in dev]
    variance = sum(deviations) / n
    std_dev = round(math.sqrt(variance),2)
    print("SATNDARD DEVIATION IS :"+ str(std_dev))#standard deviation of temperature attribute

std_devi(temperature1,temean)
std_devi(humidity1,humean)
std_devi(pressure1,prmean)
std_devi(rain1,ramean)
std_devi(lightavg1,lamean)
std_devi(lightmax1,lmmean)
std_devi(moisture1,momean)

old_df = pd.read_csv("landslide_data_original.csv")
head = list(df.columns)[2:]
rmse = []
for i in head:
    arr1 = np.array(old_df[i])
    arr2 = np.array(df[i])
    print(arr1)
    arr3 = arr1-arr2
    arr3= arr3**2
    sum_f = sum(arr3)
    sum_f = sum_f/len(df[i])
    rmse_val = sum_f**0.5
    rmse.append(rmse_val)
print(rmse)
plt.plot(head,rmse)
plt.title("RMSE vs Attributes")
plt.xlabel("Attributes")
plt.ylabel("RMSE")
plt.show()