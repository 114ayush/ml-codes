import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

data = pd.read_csv("interpolated_dataset.csv")

boxplot = data.boxplot(figsize = (5,5))
plt.title('Boxplot of Interpolated Data')
plt.ylabel('numbers')
plt.show()


data = pd.read_csv("interpolated_dataset.csv")
temperature1 = data['temperature'].tolist()
humidity1 = data['humidity'].tolist()
pressure1 = data['pressure'].tolist()
rain1 = data['rain'].tolist()
lightavg1 = data['lightavg'].tolist()
lightmax1 = data['lightmax'].tolist()
moisture1 = data['moisture'].tolist()

def outlier(out):
    Q1 = np.percentile(out, 25)
    Q3 = np.percentile(out, 75)
    IQR=Q3-Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    lst=[]
    n=len(out)
    for i in range(n):
        if(out[i]<lower_bound/out[i]>upper_bound):
            lst.append(i)
    return lst        



    


teoutlier=outlier(temperature1)
huoutlier=outlier(humidity1)
proutlier=outlier(pressure1)
raoutlier=outlier(rain1)
laoutlier=outlier(lightavg1)
lmoutlier=outlier(lightmax1)
mooutlier=outlier(moisture1)

def median(me):
    me.sort()
    # finding the median
    n = len(me)
    if n % 2 == 0:
        median = round((me[n//2 - 1] + me[n//2]) / 2,2)
    else:
        median = round(me[n//2],2)
     # Print the median of the list
    print(median)

temedian=median(temperature1)
humedian=median(humidity1)
prmedian=median(pressure1)
ramedian=median(rain1)
lamedian=median(lightavg1)
lmmedian=median(lightmax1)
momedian=median(moisture1)


for i in teoutlier:
    temperature1[i] = temedian

for i in huoutlier:
    
        humidity1[i] = humedian

for i in proutlier:
    
        pressure1[i] = prmedian

for i in raoutlier:
    
        rain1[i] = ramedian

for i in laoutlier:
    
        lightavg1[i] = lamedian

for i in lmoutlier:
    
        lightmax1[i] = lmmedian

for i in mooutlier:
    
        moisture1[i] = momedian

def attribute(box):
    rain1_df = pd.DataFrame({'outlier': box})

    # Create a boxplot using the .plot() method
    rain1_df.plot(kind='box', title='Boxplot of attribute')

    # Show the plot
    plt.show()

attribute(temperature1)
attribute(humidity1) 
attribute(pressure1)
attribute(rain1)
attribute(lightavg1)
attribute(lightmax1)   
attribute(moisture1)






