import pandas as pd
import numpy as np

# Function to perform Max-Min Normalization
def max_min_normalize(data, upper_limit, lower_limit):
    min_val = min(data)
    max_val = max(data)
    normalized_data = [(x - min_val) / (max_val - min_val) * (upper_limit - lower_limit) + lower_limit for x in data]
    return normalized_data

# Function to standardize data
def standardize_data(data):
    mean = np.mean(data)
    std_deviation = np.std(data)
    standardized_data = [(x - mean) / std_deviation for x in data]
    return standardized_data

# Read data from a CSV file
data_df = pd.read_csv("interpolated_dataset.csv")
print(data_df.columns)
#data_df.drop(columns=["Unnamed: 0"], inplace=True)
columns_to_normalize = [col for col in data_df.columns if col not in ["stationid", "dates"]]

# Normalize and standardize the data for selected columns and print statistics
for column in columns_to_normalize:
    column_data = data_df[column]
   
    # Max-Min Normalization
    max_min_normalized_data = max_min_normalize(column_data, upper_limit=12, lower_limit=5)
    print(f"Column: {column}")
    print(f"Original Maximum Value: {max(column_data):.2f}")
    print(f"Maximum Value after Max-Min Normalization: {max(max_min_normalized_data):.2f}")
    print(f"Original Minimum Value: {min(column_data):.2f}")
    print(f"Minimum Value after Max-Min Normalization: {min(max_min_normalized_data):.2f}\n")
   
    # Standardization
    standardized_data = standardize_data(column_data)
    print(f"Column: {column}")
    print(f"Mean before Standardization: {round(np.mean(column_data), 2)}")
    print(f"Mean after Standardization: {round(np.mean(standardized_data), 2)}")
    print(f"Standard Deviation before Standardization: {round(np.std(column_data), 2)}")
    print(f"Standard Deviation after Standardization: {round(np.std(standardized_data), 2)}\n")

