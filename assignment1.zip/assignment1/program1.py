import pandas as pd
import math
#PROBLEM STATEMENT 1
data = pd.read_csv("landslide_data_original.csv")
temperature1 = data['temperature'].tolist()
humidity1 = data['humidity'].tolist()
pressure1 = data['pressure'].tolist()
rain1 = data['rain'].tolist()
lightavg1 = data['lightavg'].tolist()
lightmax1 = data['lightmax'].tolist()
moisture1 = data['moisture'].tolist()
n=len(temperature1)
k=0
for i in temperature1:
    k=k+i
l=round(k/n,2)    
print("MEAN IS :" + str(l))#mean of temperature attribute

maximum = None

for number in temperature1:
    if maximum is None or maximum < number:
        maximum = round(number,2)


print("MAXIMUM IS:"+ str(maximum))  #maximum of temperature attribute

minimum = None

for number in temperature1:
    if minimum is None or number < minimum:
        minimum = round(number,2)


print("MINIMUM IS :"+ str(minimum))


temperature1.sort()
# finding the median
n = len(temperature1)
if n % 2 == 0:
    median = round((temperature1[n//2 - 1] + temperature1[n//2]) / 2,2)
else:
    median = round(temperature1[n//2],2)
# Print the median of the list
print("Median of list is : " + str(median))#median of temperature attribute


deviations = [(x - l) ** 2 for x in temperature1]
variance = sum(deviations) / n
std_dev = round(math.sqrt(variance),2)
print("SATNDARD DEVIATION IS :"+ str(std_dev))#standard deviation of temperature attribute


#PROBLEM STATEMENT 2    

def mean(m):
    k=0
    for i in m:
        k=k+i
    me=round(k/n,2)
    return me

temean=mean(temperature1)
humean=mean(humidity1)
prmean=mean(pressure1)
ramean=mean(rain1)
lamean=mean(lightavg1)
lmmean=mean(lightmax1)
momean=mean(moisture1)

def correlation(x,y,mean1,mean2):
    a=0
    r=0
    b=0
    c=0
    for q in range(0,n):
        a=a+((x[q]-mean1)*(y[q]-mean2))
        b=b+(math.pow(x[q]-mean1,2))
        c=c+(math.pow(y[q]-mean2,2))
    r=a/math.sqrt(b*c)    

        
        

    return r

l1=[temperature1,humidity1,pressure1,rain1,lightavg1,lightmax1,moisture1]
#l1 =list(data.columns)
l3 = list(data.columns)[2:]
l2=[temean,humean,prmean,ramean,lamean,lmmean,momean]

lst1=[]
for i in range(0,7):
    lst=[]
    for j in range(0,7):
       s=correlation(l1[i],l1[j],l2[i],l2[j])
       lst.append(s)
    lst1.append(lst)

grid=pd.DataFrame(lst1,columns=l3)
grid=grid.set_index(grid.columns)

print(grid)




import matplotlib.pyplot as plt



stationid_data = ["t12"] * len(humidity1)  # Assuming this corresponds to the humidity data


# Extract humidity values for stationid = t12

interestingrows=[humidity for i, humidity in enumerate(humidity1) if stationid_data[i] == "t12"]
bin_size=5

hist = {}
for humidity in interestingrows:
    bin_index = (humidity // bin_size) * bin_size
    if bin_index in hist:
        hist[bin_index] += 1
    else:
        hist[bin_index] = 1

# Extract bin values and frequencies for plotting
bins = list(hist.keys())
frequencies = list(hist.values())

# Create the histogram plot
plt.bar(bins, frequencies, width=bin_size, align='edge', edgecolor='red')
plt.title('Humidity Histogram for Station ID T12')
plt.xlabel('Humidity')
plt.ylabel('Frequency')

plt.show()






   



        
    








  


    


 
