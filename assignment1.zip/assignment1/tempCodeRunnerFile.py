df.to_csv('interpolated_dataset.csv', index=False)
